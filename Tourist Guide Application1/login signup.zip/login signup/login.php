<?php
session_start();
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($con, $_POST["username"]);
    $password = mysqli_real_escape_string($con, $_POST["password"]);

    // Validate credentials (replace this with your validation logic)
    $query = "SELECT * FROM user_tbl WHERE (Username='$username' OR Email='$username') LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $hashPassword = $row['Password'];
        if (password_verify($password, $hashPassword)) {
            $_SESSION['id']=$row['id'];
            $firstWord=$row['Username'];
            $firstName=explode(" ",$firstWord);
            $firstParts=$firstName[0];
            $_SESSION['username'] = $firstParts;
            echo "<script type='text/javascript'>;
              alert('login success');
              window.location.href = '../index.php';
              </script>";   
            exit;
        } else {
            $error_message = "Invalid password";
        }
    } else {
        $error_message = "User not found";
    }
    // Display alert box using JavaScript
    echo '<script>';
    echo 'alert("' . $error_message . '");';
    echo 'window.location.href = "login.html";';
    echo '</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
   <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Login Form</h2>
            <div class="close"><button id="close"onclick="closeForm()">&#x2715;</button></div>
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-control">
                <label>Username/Email</label>
                <input class="text" type="text" name="username" id="username" autocomplete="off"autofocus>
                <small>Error Message</small>
            </div>    
            <div class="password-input form-control">
                <label>Password</label>
                <input class="text" type="password" name="password" id="password" autocomplete="off">
                <button type="button" class="eye"onclick="passwordVisibility()">&#x1F441;&#xFE0F;</button>
                <div class="cross-line"></div>
                <small>Error Message</small>
            </div>
            <div class="btn-group">
                <input type="submit" value="Submit" id="submit" name="submit" class="btn">
                <input type="reset" value="Reset" id="reset" name="reset" class="btn">
            </div><br>
            <h3>Don't have an account?<a style="font-size:16px;font-weight:500;color:rgb(25, 0, 255);text-underline-offset: none;" href="Signup.php" target="_parent">Sign Up</a></h3><br>
            <h3><a style="font-size:16px;font-weight:500;color:rgb(25, 0, 255);text-underline-offset: none;" href="send_reset_link.php" target="_parent">Forget password</a></h3>
        </form>
    </div>
    <script>
       function passwordVisibility() {
    const passwordInput = document.getElementById('password');
    const crossLine = document.querySelector('.cross-line');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        crossLine.style.display = 'none';
    } else {
        passwordInput.type = 'password';
        crossLine.style.display = 'block';
    }
}
   function closeForm(){
        const container=document.querySelector('.container');
        container.style.display='none';
        window.location.replace('../index.php');
    }
    </script>
</body>
</html>

